#!/bin/bash

echo "#########################################"
echo "Installing QtumJS"
npm install

echo "#########################################"
echo "fetching data of task id" $1
mkdir data
cd data
wget http://127.0.0.1:8000/files/$1.zip

echo "#########################################"
echo "unzipping file" $1.zip
unzip ./$1.zip
rm $1.zip
cd $1
filename="cmd.txt"

input="cmd.txt"
while IFS= read -r var
do
echo "#########################################"
echo "exectuing command - $var"
$var
done < "$input"

echo "#########################################"
cd ..
zip -r $1 $1.zip

echo "#########################################"
echo "initiating transaction - "
cd ..
node compute.js $2

echo "#########################################"
echo "Uploading results - "

wget --quiet \
  --method POST \
  --header 'Cache-Control: no-cache' \
  --header 'Postman-Token: 64a1ad83-28db-44e5-bc84-3e85938bb0cf' \
  --output-document \
  - http://127.0.0.1:8000/results ./data/$1.zip

echo "#########################################"
echo "end "

rm -r data


